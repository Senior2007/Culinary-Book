from uuid import UUID
from dataclasses import dataclass
from typing import List

@dataclass
class Credentials:
    id: UUID
    login: str
    password_hashes: List[str]