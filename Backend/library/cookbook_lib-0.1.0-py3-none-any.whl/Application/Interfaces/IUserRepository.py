from abc import ABC, abstractmethod
from uuid import UUID
from Domain.Entities.User.User import User

class IUserRepository(ABC):
    @abstractmethod
    async def get_by_id(self, user_id: UUID) -> User: pass

    @abstractmethod
    async def save(self, user: User): pass

    @abstractmethod
    async def get_by_login(self, login: str): pass